//
//  CoreData.swift
//  PlacesYouveBeen
//
//  Created by Sean Mitchell on 15/12/2017.
//  Copyright © 2017 Sean Mitchell. All rights reserved.
//

import CoreData

struct CoreData {
    static let shared = CoreData()
    
    let persistantContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "PlacesYouveBeen")
        container.loadPersistentStores(completionHandler: {(storeDescription, err) in
            if let err = err{
                fatalError("\(err)")
            }
        })
        return container
    }()
    
    func fetchLocation() -> [Location] {
        let context = persistantContainer.viewContext
        let fetchRequest = NSFetchRequest<Location>(entityName: "Location")
        do {
            let location = try context.fetch(fetchRequest)
            return location
        } catch let error{
            print(error)
            return []
        }
    }
    
    func saveLocation(name: String) {
        let context = persistantContainer.viewContext
        let location = NSEntityDescription.insertNewObject(forEntityName: "Location", into: context) as! Location
        location.setValue(name, forKey: "name")
        do {
            try context.save()
        } catch let error{
            print(error)
        }
    }
}
