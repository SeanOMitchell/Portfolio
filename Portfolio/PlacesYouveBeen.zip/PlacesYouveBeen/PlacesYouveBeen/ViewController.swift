//
//  ViewController.swift
//  PlacesYouveBeen
//
//  Created by Sean Mitchell on 15/12/2017.
//  Copyright © 2017 Sean Mitchell. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func saveBttnPress(_ sender: Any) {
        var locationName: String
        let saveLocation = CoreData()
        if placesInput.text != ""{
            locationName = placesInput.text!
            saveLocation.saveLocation(name: locationName)
        }
        tableView.reloadData()
        placesInput.resignFirstResponder()
    }
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let placesArray = CoreData.shared.fetchLocation()
        return placesArray.count
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: UITableViewCellStyle.default, reuseIdentifier: "Cell")
        let placesArray = CoreData.shared.fetchLocation()
        cell.textLabel?.text = placesArray[indexPath.row].name
        return cell
    }
    
    
    
    @IBOutlet weak var placesInput: UITextField!
    @IBOutlet weak var tableView: UITableView!
}

