//
//  ViewController.swift
//  Times Tables
//
//  Created by Sean Mitchell on 20/10/2017.
//  Copyright © 2017 Sean Mitchell. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.timesTablesView.delegate = self
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBOutlet weak var timesTableInput: UITextField!
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        let aSet = NSCharacterSet(charactersIn:"0123456789").inverted
        let compSepByCharInSet = string.components(separatedBy: aSet)
        let numberFiltered = compSepByCharInSet.joined(separator: "")
        return string == numberFiltered
    }
    
    @IBAction func inputSave(_ sender: Any) {
        timesTablesView.reloadData()
        timesTableInput.resignFirstResponder()
    }
    
    @IBOutlet weak var timesTablesView: UITableView!
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 20
    }
    
    
    // Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
    // Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: UITableViewCellStyle.default, reuseIdentifier: "Cell")
        let timesTable = Int(timesTableInput.text!)
        if timesTable != nil{
            let timesTableAnswer = String(timesTable! * (indexPath.row + 1))
            cell.textLabel?.text = String(timesTable!) + " X " + String(indexPath.row + 1) + " = " + timesTableAnswer
        }
        return cell
    }
}

