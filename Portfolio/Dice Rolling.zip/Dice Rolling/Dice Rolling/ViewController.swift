//
//  ViewController.swift
//  Dice Rolling
//
//  Created by Sean Mitchell on 06/10/2017.
//  Copyright © 2017 Sean Mitchell. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var guessInput: UITextField!
    
    @IBAction func guessBtn(_ sender: Any) {
        let inputGuess = Int(guessInput.text!)
        
        guessInput.text = ""
        
        guessInput.resignFirstResponder()
        
        let diceRoll1 = arc4random_uniform(6) + 1
        let diceRoll2 = arc4random_uniform(6) + 1
        let rollAnswer = Int(diceRoll1 + diceRoll2)
        
        if (inputGuess == rollAnswer) {
            resultTxt.text = "You guessed the right answer!"
        }
        else{
            resultTxt.text = "You guessed the wrong answer.. I rolled \(rollAnswer)"
        }
        
    }
    
    @IBOutlet weak var resultTxt: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

