//
//  CoreData.swift
//  MapApp
//
//  Created by Sean Mitchell on 15/12/2017.
//  Copyright © 2017 Sean Mitchell. All rights reserved.
//

import CoreData

struct CoreData {
    static let shared = CoreData()
    
    let persistantContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "MapApp")
        container.loadPersistentStores(completionHandler: {(storeDescription, err) in
            if let err = err{
                fatalError("\(err)")
            }
        })
        return container
    }()
    
    func fetchLocation() -> [Location] {
        let context = persistantContainer.viewContext
        let fetchRequest = NSFetchRequest<Location>(entityName: "Location")
        do {
            let location = try context.fetch(fetchRequest)
            return location
        } catch let error{
            print(error)
            return []
        }
    }
    
    func deleteLocation(item: Int){
        let context = persistantContainer.viewContext
        let fetchRequest = NSFetchRequest<Location>(entityName: "Location")
        do {
            let location = try context.fetch(fetchRequest)
            var index = 0
            location.forEach{(place) in
                if index == item{
                    context.delete(place)
                }
                index+=1
            }
        } catch let error{
            print(error)
            return
        }
    }
    
    func saveLocation(name: String, lat: Double, long: Double) {
        let context = persistantContainer.viewContext
        let location = NSEntityDescription.insertNewObject(forEntityName: "Location", into: context) as! Location
        location.setValue(name, forKey: "name")
        location.setValue(lat, forKey: "lat")
        location.setValue(long, forKey: "long")
        do {
            try context.save()
        } catch let error{
            print(error)
        }
    }
}

